USE [CraftStoreDB_DEV]
GO

INSERT INTO [dbo].[Customer]
           ([LastName]
           ,[FirstName])
     VALUES
           ('Doe'
           ,'Becky'),
		   ('Mill'
           ,'Cindy'),
		   ('Mill'
           ,'Mike'),
		   ('Pitt'
           ,'Denise'),
		   ('Mill'
           ,'Jason'),
		   ('Pitt'
           ,'Justin'),
		   ('Pitt'
           ,'Layla')
GO


